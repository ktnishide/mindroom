<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Document</title>
	<link rel="stylesheet" href="css/style.css">
  <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
</head>
<body>
  <div class="logo"></div>
  <div class="login-block">
    <h1>Login</h1>
    <form action="page2.php" method="post">
      <input type="text" name="uname" placeholder="Enter Username" id="username"/>
      <input type="password" name="pwd" placeholder="Enter Password" id="password"/>
      <input type="submit" value="Login"id="button"/>
    </form>
  </div>
</body>
</html>